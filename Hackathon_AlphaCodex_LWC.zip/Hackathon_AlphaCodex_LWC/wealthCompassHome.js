import { LightningElement } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import invokeWealthAdvisoryAgent from '@salesforce/apex/WealthCompassAgentLauncher.invokeWealthAdvisoryAgent';
import { formatAgentDisplayText, isGenericRefusal } from './agentResponseFormat';

const NESTCOMPASS_WELCOME =
    'Welcome to NestCompass. Ask anything about your clients, portfolios, or next best actions — type below and press Send.';

export default class WealthCompassHome extends LightningElement {
    activeTab = 'home';
    launching = false;
    modalBusy = false;
    agentSessionId;
    draftMessage = '';
    transcript = [];
    modalError;
    _lineId = 0;

    get isHomeTab() {
        return this.activeTab === 'home';
    }

    get isNestTab() {
        return this.activeTab === 'nest';
    }

    get homeTabClass() {
        return this.isHomeTab ? 'wc-nav-tab wc-nav-tab_active' : 'wc-nav-tab';
    }

    get nestTabClass() {
        return this.isNestTab ? 'wc-nav-tab wc-nav-tab_active' : 'wc-nav-tab';
    }

    get homeAriaCurrent() {
        return this.isHomeTab ? 'page' : null;
    }

    get nestAriaCurrent() {
        return this.isNestTab ? 'page' : null;
    }

    connectedCallback() {
        this._onKeydown = (e) => {
            if (e.key === 'Escape' && this.isNestTab) {
                this.activeTab = 'home';
            }
        };
        window.addEventListener('keydown', this._onKeydown);
    }

    disconnectedCallback() {
        window.removeEventListener('keydown', this._onKeydown);
    }

    handleDraftChange(event) {
        this.draftMessage = event.target.value;
    }

    handleSelectHome() {
        this.activeTab = 'home';
    }

    handleSelectNest() {
        this.activeTab = 'nest';
        if (this.transcript.length === 0) {
            this.pushLine('agent', NESTCOMPASS_WELCOME);
        }
    }

    pushLine(role, text) {
        const id = `wc-${++this._lineId}`;
        const isUser = role === 'user';
        this.transcript = [
            ...this.transcript,
            {
                id,
                role,
                text,
                label: isUser ? 'You' : 'NestCompass',
                rowClass: isUser ? 'wc-chat-row wc-chat-row_user' : 'wc-chat-row wc-chat-row_agent'
            }
        ];
    }

    async handleAskNestCompass() {
        if (this.launching) {
            return;
        }
        this.launching = true;
        this.activeTab = 'nest';
        this.modalBusy = true;
        this.modalError = null;
        this.transcript = [];
        this.agentSessionId = null;
        this.draftMessage = '';
        this.pushLine('agent', NESTCOMPASS_WELCOME);

        try {
            await this.runAgentTurn('', { allowSuppressRefusal: true });
        } catch (error) {
            this.modalError = this.reduceError(error);
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'NestCompass request failed',
                    message: this.modalError,
                    variant: 'error',
                    mode: 'sticky'
                })
            );
        } finally {
            this.modalBusy = false;
            this.launching = false;
        }
    }

    async handleSendFollowUp() {
        const text = (this.draftMessage || '').trim();
        if (!text) {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Add a message',
                    message: 'Type what you want to ask NestCompass, then press Send.',
                    variant: 'info'
                })
            );
            return;
        }
        if (this.modalBusy) {
            return;
        }
        this.pushLine('user', text);
        this.draftMessage = '';
        this.modalBusy = true;
        this.modalError = null;
        try {
            await this.runAgentTurn(text, { allowSuppressRefusal: false });
        } catch (error) {
            this.modalError = this.reduceError(error);
        } finally {
            this.modalBusy = false;
        }
    }

    async runAgentTurn(userMessage, options = {}) {
        const { allowSuppressRefusal = false } = options;

        const result = await invokeWealthAdvisoryAgent({
            userMessage,
            sessionId: this.agentSessionId
        });

        if (result?.success) {
            if (result.sessionId) {
                this.agentSessionId = result.sessionId;
            }
            const raw = result.agentResponse;
            const reply = formatAgentDisplayText(raw);
            const display = (reply || raw || '').trim();

            if (allowSuppressRefusal && isGenericRefusal(display)) {
                return;
            }

            if (display) {
                this.pushLine('agent', display);
            } else if (!allowSuppressRefusal) {
                this.pushLine('agent', 'NestCompass responded.');
            }
        } else {
            this.modalError =
                result?.errorMessage ||
                'Confirm the Wealth_Advisory_Agent exists, is active, and Einstein Agent actions are enabled.';
        }
    }

    reduceError(error) {
        if (Array.isArray(error?.body)) {
            return error.body.map((e) => e.message).join(', ');
        }
        if (typeof error?.body?.message === 'string') {
            return error.body.message;
        }
        if (typeof error?.message === 'string') {
            return error.message;
        }
        return 'Unexpected error while calling the agent.';
    }
}