export function isGenericRefusal(text) {
    const s = (text || '').toLowerCase().trim();
    if (!s) {
        return true;
    }
    const refusalSnippets = [
        "sorry, i can't assist",
        "sorry, i cannot assist",
        "i can't assist with that",
        "i cannot assist with that",
        "i'm not able to assist",
        "unable to assist with that",
        "can't help with that",
        "cannot help with that"
    ];
    return refusalSnippets.some((needle) => s.includes(needle));
}

export function formatAgentDisplayText(raw) {
    if (raw == null) {
        return '';
    }
    let s = String(raw).trim();
    if (!s) {
        return '';
    }
    s = stripCodeFence(s);

    for (let i = 0; i < 5; i++) {
        const next = tryUnwrapAgentJsonEnvelope(s);
        if (next == null || next === s) {
            break;
        }
        s = next;
    }
    return s;
}

function stripCodeFence(s) {
    const m = s.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
    return m ? m[1].trim() : s;
}

function tryUnwrapAgentJsonEnvelope(s) {
    const t = s.trim();
    if (!t || (t[0] !== '{' && t[0] !== '[')) {
        return null;
    }
    let parsed;
    try {
        parsed = JSON.parse(t);
    } catch {
        return null;
    }
    const extracted = extractTextFromAgentPayload(parsed);
    if (extracted == null) {
        return null;
    }
    const out = String(extracted).trim();
    return out.length ? out : null;
}

function extractTextFromAgentPayload(node) {
    if (node == null) {
        return null;
    }
    if (typeof node === 'string') {
        return node;
    }
    if (typeof node === 'number' || typeof node === 'boolean') {
        return String(node);
    }
    if (Array.isArray(node)) {
        const parts = node
            .map((item) => extractTextFromAgentPayload(item))
            .filter((p) => p != null && String(p).trim().length);
        return parts.length ? parts.join('\n\n') : null;
    }
    if (typeof node === 'object') {
        if (Object.prototype.hasOwnProperty.call(node, 'value')) {
            const v = node.value;
            if (typeof v === 'string') {
                return v;
            }
            if (typeof v === 'number' || typeof v === 'boolean') {
                return String(v);
            }
            if (v != null && typeof v === 'object') {
                return extractTextFromAgentPayload(v);
            }
        }
        if (typeof node.message === 'string') {
            return node.message;
        }
        if (typeof node.text === 'string') {
            return node.text;
        }
        if (typeof node.body === 'string') {
            return node.body;
        }
        if (typeof node.output === 'string') {
            return node.output;
        }
    }
    return null;
}