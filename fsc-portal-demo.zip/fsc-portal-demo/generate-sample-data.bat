@echo off
cd /d "%~dp0"
node scripts\generate-data.js
pause
