Four datasets in CSV AND (when deps installed) Excel .xlsx format.
Matching Client_ID: CUST-1001 … CUST-1450 (450 unified clients total).
First customer row aligns with Sneha Sharma sample across portals.

Portal: Import the matching workbook into Banking / Insurance / Employment / Trading,
then Sync to Salesforce Data Cloud (configure DATA_CLOUD_INGEST_URL in server .env).