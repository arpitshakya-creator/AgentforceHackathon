/* global XLSX */
(function () {
  const JSON_COLUMNS = [
    'Household_Members',
    'Recent_Transactions',
    'Beneficiaries',
    'Claims_History',
    'Work_Milestones',
    'Holding_Symbols',
    'Recent_Trades',
    'Market_Alerts'
  ];

  const THEMES = {
    banking: {
      title: 'Retail Banking Portal',
      slug: 'banking',
      accent: '#1565c0',
      accent2: '#0d47a1',
      subtitle: 'Relationship data, KYC, accounts, balances, and channel preference.'
    },
    insurance: {
      title: 'Insurance Self-Service',
      slug: 'insurance',
      accent: '#2e7d32',
      accent2: '#1b5e20',
      subtitle: 'Policies, premiums, beneficiaries, and claims.'
    },
    employment: {
      title: 'Employment & Careers Portal',
      slug: 'employment',
      accent: '#6a1b9a',
      accent2: '#4a148c',
      subtitle: 'Employer, role, compensation, milestones, and work email.'
    },
    trading: {
      title: 'Trading & Investments',
      slug: 'trading',
      accent: '#c62828',
      accent2: '#b71c1c',
      subtitle: 'Portfolio, risk profile, trades, and market alerts.'
    }
  };

  const slug = window.PORTAL_SLUG || 'banking';
  const theme = THEMES[slug] || THEMES.banking;

  document.documentElement.style.setProperty('--accent', theme.accent);
  document.documentElement.style.setProperty('--accent2', theme.accent2);
  document.getElementById('portal-title').textContent = theme.title;
  document.getElementById('portal-desc').textContent = theme.subtitle;

  /** @type {object[]} */
  let parsedRows = [];

  function enrichRow(row) {
    const out = { ...row };
    for (const col of JSON_COLUMNS) {
      if (typeof out[col] !== 'string') continue;
      const t = out[col].trim();
      if (!t.startsWith('[') && !t.startsWith('{')) continue;
      try {
        out[col] = JSON.parse(out[col]);
      } catch {
        /* keep string */
      }
    }
    return out;
  }

  function stringifyForCell(val) {
    if (val === null || val === undefined) return '';
    if (typeof val === 'object') return JSON.stringify(val);
    return String(val);
  }

  function renderTable(rows) {
    const host = document.getElementById('table-host');
    if (!rows.length) {
      host.innerHTML =
        '<p class="muted">Import an Excel file to preview records. Rows will push to Salesforce Data Cloud.</p>';
      return;
    }
    const keys = Object.keys(rows[0]);
    const thead = `<thead><tr>${keys.map((k) => `<th>${escapeHtml(k)}</th>`).join('')}</tr></thead>`;
    const tbody = rows
      .slice(0, 200)
      .map(
        (row) =>
          `<tr>${keys.map((k) => `<td title="${escapeAttr(stringifyForCell(row[k]))}">${summarizeCell(row[k])}</td>`).join('')}</tr>`
      )
      .join('');
    const more =
      rows.length > 200
        ? `<p class="muted">Showing first 200 of ${rows.length} rows. Full payload syncs all rows.</p>`
        : '';
    host.innerHTML = `<div class="table-wrap"><table>${thead}<tbody>${tbody}</tbody></table></div>${more}`;
  }

  function summarizeCell(val) {
    if (val === null || val === undefined) return '';
    if (typeof val === 'object')
      return `<code class="json-snippet">${escapeHtml(JSON.stringify(val))}</code>`;
    const s = String(val);
    return escapeHtml(s.length > 140 ? `${s.slice(0, 137)}…` : s);
  }

  function escapeHtml(t) {
    return String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
  }

  function escapeAttr(t) {
    return escapeHtml(t).replace(/'/g, '&#39;');
  }

  function humanizeSyncError(text) {
    if (text == null || typeof text !== 'string') return String(text);
    if (/^JWT bearer:/i.test(text.trim())) return text;
    const t = text.trim();
    if (!t.startsWith('{')) return text;
    try {
      const o = JSON.parse(t);
      const code = o.error;
      if (code === 'invalid_grant') {
        return (
          'Salesforce rejected the token request (invalid_grant). ' +
          'Password flow: username + password+security token in SALESFORCE_PASSWORD. ' +
          'JWT flow: certificate on the Connected App must match keys/server.key; pre-authorize ' +
          'SALESFORCE_USERNAME for that app. Refresh flow: re-run oauth-once. Raw: ' +
          t
        );
      }
      if (code === 'invalid_scope') {
        return (
          'Connected App missing Data Cloud scope (invalid_scope). Add cdp_ingest_api to the OAuth app and reconnect. Raw: ' + t
        );
      }
      if (code === 'invalid_request') {
        return (o.error_description || 'invalid_request') + ' — Raw: ' + t;
      }
    } catch {
      /* ignore */
    }
    return text;
  }

  function setStatus(ok, msg) {
    const el = document.getElementById('status');
    el.className = 'status show ' + (ok ? 'ok' : 'err');
    el.textContent = msg;
  }

  function hideStatus() {
    const el = document.getElementById('status');
    el.className = 'status';
    el.textContent = '';
  }

  document.getElementById('file-import').addEventListener('change', (e) => {
    hideStatus();
    const f = e.target.files && e.target.files[0];
    if (!f) return;

    const reader = new FileReader();
    reader.onload = function load(ev) {
      try {
        const data = new Uint8Array(ev.target.result);
        const wb = XLSX.read(data, { type: 'array' });
        const wsName = wb.SheetNames[0];
        const ws = wb.Sheets[wsName];
        const rows = XLSX.utils.sheet_to_json(ws, { defval: '' });
        parsedRows = rows.map((r) => enrichRow(r));
        document.getElementById('row-count').textContent = String(parsedRows.length);
        document.getElementById('sync-row').classList.toggle('hidden', parsedRows.length === 0);
        document.getElementById('btn-sync').classList.toggle('hidden', parsedRows.length === 0);
        renderTable(parsedRows);
        setStatus(true, `Loaded ${parsedRows.length} rows from "${f.name}".`);
      } catch (err) {
        parsedRows = [];
        renderTable([]);
        setStatus(false, 'Could not read Excel: ' + (err.message || err));
      }
    };
    reader.readAsArrayBuffer(f);
  });

  document.getElementById('btn-sync').addEventListener('click', async () => {
    hideStatus();
    if (!parsedRows.length) {
      setStatus(false, 'No data loaded.');
      return;
    }
    const btn = document.getElementById('btn-sync');
    btn.disabled = true;
    try {
      const res = await fetch('/api/push-to-salesforce', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ source: theme.slug, records: parsedRows })
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) {
        const errText =
          typeof body.error === 'string'
            ? body.error
            : body.error
              ? JSON.stringify(body.error).slice(0, 800)
              : `HTTP ${res.status}`;
        setStatus(false, humanizeSyncError(errText));
        return;
      }
      let msg = 'Sent to Data Cloud.';
      if (body.mode === 'data_cloud_streaming' && body.upstream && body.upstream.batches) {
        const last = body.upstream.batches[body.upstream.batches.length - 1];
        msg = `Sync OK (${body.upstream.batches.length} batch(es)) — ${body.upstream.urlUsed || 'ingest API'}`;
        if (last && last.status) msg += ` Last HTTP ${last.status}.`;
      }
      if (body.dryRun) msg = 'Dry run — no outbound call.';
      setStatus(true, msg);
    } catch (err) {
      setStatus(false, err.message || 'Network error');
    } finally {
      btn.disabled = false;
    }
  });

  renderTable([]);
})();
