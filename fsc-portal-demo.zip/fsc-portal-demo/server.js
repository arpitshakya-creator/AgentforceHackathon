/**
 * FSC Portal demo: static sites + optional Salesforce Data Cloud Streaming Ingest
 * (JWT bearer, Connected App refresh, password grant, or static token).
 */
require('dotenv').config();
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const express = require('express');
const cors = require('cors');

const PORT = Number(process.env.PORT) || 3780;
const SOURCE_KEYS = ['banking', 'insurance', 'employment', 'trading'];

const SOURCE_TO_OBJECT = {
  banking: 'Banking_Customer',
  insurance: 'Insurance_Customer',
  employment: 'Employment_Customer',
  trading: 'Trading_Customer'
};

const STREAMING_MAX_BODY_CHARS = Number(process.env.DATA_CLOUD_MAX_BODY_CHARS) || 180 * 1024;

const app = express();
app.use(cors());
app.use(express.json({ limit: '50mb' }));

const INGEST_SCHEMA_FILE = path.resolve(
  __dirname,
  'public',
  'schemas',
  'fsc-portal-demo-ingestion.openapi.yaml'
);

app.get('/download/fsc-portal-demo-ingestion.openapi.yaml', (req, res) => {
  if (!fs.existsSync(INGEST_SCHEMA_FILE)) {
    return res.status(404).send('Schema file not found');
  }
  res.setHeader('Content-Type', 'application/yaml');
  res.setHeader(
    'Content-Disposition',
    'attachment; filename="fsc-portal-demo-ingestion.openapi.yaml"'
  );
  res.sendFile(INGEST_SCHEMA_FILE, (err) => {
    if (err && !res.headersSent) res.status(500).send('Could not send schema file');
  }  );
});

/** OAuth redirect target — must exactly match SALESFORCE_REDIRECT_URI and External Client App Callback URL */
function escapeHtml(s) {
  return String(s || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/"/g, '&quot;');
}

app.get('/oauth/callback', (req, res) => {
  const err = req.query.error;
  const desc = req.query.error_description;
  const code = req.query.code;
  if (err) {
    return res.status(400).type('html').send(
      `<!DOCTYPE html><html><meta charset="utf-8"><title>OAuth error</title><body style="font-family:sans-serif;padding:1.5rem;">` +
        `<h2>OAuth error</h2><p><strong>${escapeHtml(err)}</strong></p>` +
        `<pre>${escapeHtml(desc || '')}</pre>` +
        `<p>Ensure External Client App <strong>Callback URL</strong> equals <code>SALESFORCE_REDIRECT_URI</code> in <code>.env</code>.</p>` +
        `</body></html>`
    );
  }
  if (!code) {
    return res.status(400).type('html').send(
      '<html><body>Missing code. Expected Salesforce to redirect here with ?code=…</body></html>'
    );
  }
  const fullUrl = `${req.protocol}://${req.get('host')}${req.originalUrl}`;
  res.type('html').send(`<!DOCTYPE html>
<html lang="en"><meta charset="utf-8"/><title>OAuth OK</title>
<body style="font-family:system-ui,sans-serif;padding:1.5rem;line-height:1.5;">
  <h2>Authorization succeeded</h2>
  <p>Copy the <strong>full URL</strong> below into the terminal that is running <code>npm run oauth-once</code>:</p>
  <textarea readonly style="width:100%;max-width:900px;height:100px;font-size:12px">${escapeHtml(
    fullUrl
  )}</textarea>
  <p class="muted">Or copy from the browser address bar — then paste where the script asks.</p>
</body></html>`);
});

app.use(express.static(path.join(__dirname, 'public')));
app.use('/data', express.static(path.join(__dirname, 'data')));

function getSubjectAccessTokenStatic() {
  if (process.env.SALESFORCE_ACCESS_TOKEN) {
    return process.env.SALESFORCE_ACCESS_TOKEN.trim();
  }
  const h = process.env.DATA_CLOUD_AUTH_HEADER;
  if (h && /^Bearer\s+/i.test(h)) {
    return h.replace(/^Bearer\s+/i, '').trim();
  }
  return null;
}

function hasPreexchangedCdpToken() {
  return Boolean((process.env.DATA_CLOUD_CDP_ACCESS_TOKEN || '').trim());
}

function hasRefreshCredentials() {
  return Boolean(
    (process.env.SALESFORCE_REFRESH_TOKEN || '').trim() &&
      (process.env.SALESFORCE_CLIENT_ID || '').trim() &&
      (process.env.SALESFORCE_CLIENT_SECRET || '').trim()
  );
}

function hasJwtKeyConfigured() {
  const inline = (process.env.SALESFORCE_JWT_PRIVATE_KEY || '').trim();
  const p = (process.env.SALESFORCE_JWT_KEY_PATH || '').trim();
  return Boolean(inline || p);
}

/**
 * JWT Bearer grant: Connected App digital signature + integration user username.
 * No client_secret on token POST. See .env.example and /api/sync-help.
 */
function useJwtBearer() {
  return (
    hasJwtKeyConfigured() &&
    (process.env.SALESFORCE_CLIENT_ID || '').trim() &&
    (process.env.SALESFORCE_USERNAME || '').trim()
  );
}

function loadJwtPrivateKeyPem() {
  const inline = (process.env.SALESFORCE_JWT_PRIVATE_KEY || '').trim();
  if (inline) {
    return inline.replace(/\\n/g, '\n');
  }
  const keyPath = (process.env.SALESFORCE_JWT_KEY_PATH || '').trim();
  if (!keyPath) return null;
  const resolved = path.isAbsolute(keyPath) ? keyPath : path.resolve(__dirname, keyPath);
  if (!fs.existsSync(resolved)) {
    throw new Error(`SALESFORCE_JWT_KEY_PATH not found: ${resolved}`);
  }
  return fs.readFileSync(resolved, 'utf8');
}

function jwtAudienceForLoginBase(loginBase) {
  const fromEnv = (process.env.SALESFORCE_JWT_AUDIENCE || '').trim();
  if (fromEnv) return fromEnv.replace(/\/$/, '');
  const u = (loginBase || 'https://login.salesforce.com').replace(/\/$/, '');
  return u;
}

function signJwtRs256(privateKeyPem, payload) {
  const header = { alg: 'RS256', typ: 'JWT' };
  const enc = (obj) =>
    Buffer.from(JSON.stringify(obj), 'utf8')
      .toString('base64')
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');
  const h = enc(header);
  const p = enc(payload);
  const data = `${h}.${p}`;
  const sign = crypto.createSign('RSA-SHA256');
  sign.update(data, 'utf8');
  sign.end();
  const sig = sign
    .sign(privateKeyPem)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
  return `${data}.${sig}`;
}

/** Optional dev/demo: OAuth password grant (must be allowed on the Connected App). */
function usePasswordGrant() {
  return (
    String(process.env.SALESFORCE_USE_PASSWORD_GRANT || '').toLowerCase() === 'true' &&
    (process.env.SALESFORCE_USERNAME || '').trim() &&
    (process.env.SALESFORCE_PASSWORD || '').trim() &&
    (process.env.SALESFORCE_CLIENT_ID || '').trim() &&
    (process.env.SALESFORCE_CLIENT_SECRET || '').trim()
  );
}

function useNativeDataCloudStreaming() {
  if (process.env.DATA_CLOUD_INGEST_URL) return false;
  const connector = process.env.DATA_CLOUD_CONNECTOR_API_NAME || 'Data_Cloud_Connector';
  if (!connector) return false;

  if (hasPreexchangedCdpToken()) {
    return Boolean((process.env.DATA_CLOUD_TENANT_HOSTNAME || '').trim());
  }
  if (useJwtBearer()) {
    return true;
  }
  if (hasRefreshCredentials()) {
    return true;
  }
  if (usePasswordGrant()) {
    return true;
  }
  return Boolean(
    process.env.SALESFORCE_INSTANCE_URL?.trim() && getSubjectAccessTokenStatic()
  );
}

function getLegacyIngestUrl(source) {
  const map = {
    banking: process.env.BANKING_INGEST_URL,
    insurance: process.env.INSURANCE_INGEST_URL,
    employment: process.env.EMPLOYMENT_INGEST_URL,
    trading: process.env.TRADING_INGEST_URL
  };
  return map[source] || process.env.DATA_CLOUD_INGEST_URL;
}

function ingestApiBase(hostnameOrUrl) {
  const trimmed = String(hostnameOrUrl).trim().replace(/\/$/, '');
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return `https://${trimmed}`;
}

function jwtExpiryMs(accessToken) {
  try {
    const sec = accessToken.split('.')[1];
    if (!sec) return 0;
    const pad = sec + '='.repeat((4 - (sec.length % 4)) % 4);
    const json = JSON.parse(
      Buffer.from(pad.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8')
    );
    return json.exp ? json.exp * 1000 : 0;
  } catch {
    return 0;
  }
}

let sfCoreCache = { accessToken: '', instanceUrl: '', expiresAtMs: 0 };
let cdpBearerCache = { token: '', apiBase: '', expiresAtMs: 0 };

async function resolveCoreAccessTokenAndInstance() {
  const login = (process.env.SALESFORCE_LOGIN_URL || 'https://login.salesforce.com').replace(
    /\/$/,
    ''
  );

  if (useJwtBearer()) {
    const now = Date.now();
    if (
      sfCoreCache.accessToken &&
      sfCoreCache.instanceUrl &&
      sfCoreCache.expiresAtMs - 60_000 > now
    ) {
      return {
        accessToken: sfCoreCache.accessToken,
        instanceUrl: sfCoreCache.instanceUrl.replace(/\/$/, '')
      };
    }

    const privateKeyPem = loadJwtPrivateKeyPem();
    if (!privateKeyPem) {
      throw new Error('JWT: set SALESFORCE_JWT_PRIVATE_KEY or SALESFORCE_JWT_KEY_PATH');
    }
    const issuer = process.env.SALESFORCE_CLIENT_ID.trim();
    const subject = process.env.SALESFORCE_USERNAME.trim();
    const aud = jwtAudienceForLoginBase(login);
    const nowSec = Math.floor(Date.now() / 1000);
    const assertion = signJwtRs256(privateKeyPem, {
      iss: issuer,
      sub: subject,
      aud,
      exp: nowSec + 175,
      iat: nowSec
    });

    const body = new URLSearchParams({
      grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
      assertion
    });

    const res = await fetch(`${login}/services/oauth2/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString()
    });
    const text = await res.text();
    let json;
    try {
      json = JSON.parse(text);
    } catch {
      throw new Error(`JWT bearer response not JSON: ${text.slice(0, 400)}`);
    }
    if (!res.ok) {
      const desc = (json && json.error_description) || '';
      throw new Error(
        `JWT bearer: ${json.error || 'error'}${desc ? ` — ${desc}` : ''}. ` +
          'Fix: (1) CERT + KEY pair: keys/server.crt must be uploaded on the SAME Connected App as Consumer Key uses in `iss`; keys/server.key must pair with that .crt file. ' +
          '(2) SALESFORCE_CLIENT_ID = that app Consumer Key only (Setup → App Manager → your JWT app → View consumer details; this is not the client secret). ' +
          '(3) User "' +
          subject +
          '" — with "All users can self-authorize", log in as that user once if Salesforce still asks to approve the app; or use Permission Sets / Profiles. ' +
          '(4) Optional SALESFORCE_JWT_AUDIENCE for login/My Domain mismatch. Raw: ' +
          JSON.stringify(json)
      );
    }

    const accessToken = json.access_token;
    const instanceUrl = (
      json.instance_url ||
      process.env.SALESFORCE_INSTANCE_URL ||
      ''
    ).replace(/\/$/, '');
    const expMs = jwtExpiryMs(accessToken) || now + 90 * 60 * 1000;

    sfCoreCache = { accessToken, instanceUrl, expiresAtMs: expMs };
    console.log('[Salesforce] access token obtained via OAuth JWT bearer flow');
    return { accessToken, instanceUrl };
  }

  if (hasRefreshCredentials()) {
    const now = Date.now();
    if (
      sfCoreCache.accessToken &&
      sfCoreCache.instanceUrl &&
      sfCoreCache.expiresAtMs - 60_000 > now
    ) {
      return {
        accessToken: sfCoreCache.accessToken,
        instanceUrl: sfCoreCache.instanceUrl.replace(/\/$/, '')
      };
    }

    const body = new URLSearchParams({
      grant_type: 'refresh_token',
      refresh_token: process.env.SALESFORCE_REFRESH_TOKEN.trim(),
      client_id: process.env.SALESFORCE_CLIENT_ID.trim(),
      client_secret: process.env.SALESFORCE_CLIENT_SECRET.trim()
    });

    const res = await fetch(`${login}/services/oauth2/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString()
    });
    const text = await res.text();
    let json;
    try {
      json = JSON.parse(text);
    } catch {
      throw new Error(`Refresh token response not JSON: ${text.slice(0, 400)}`);
    }
    if (!res.ok) {
      throw new Error(JSON.stringify(json));
    }

    const accessToken = json.access_token;
    const instanceUrl = (
      json.instance_url ||
      process.env.SALESFORCE_INSTANCE_URL ||
      ''
    ).replace(/\/$/, '');
    const expMs = jwtExpiryMs(accessToken) || now + 90 * 60 * 1000;

    sfCoreCache = {
      accessToken,
      instanceUrl,
      expiresAtMs: expMs
    };

    console.log('[Salesforce] access token refreshed via Connected App (refresh_token grant)');
    return { accessToken, instanceUrl };
  }

  if (usePasswordGrant()) {
    const now = Date.now();
    if (
      sfCoreCache.accessToken &&
      sfCoreCache.instanceUrl &&
      sfCoreCache.expiresAtMs - 60_000 > now
    ) {
      return {
        accessToken: sfCoreCache.accessToken,
        instanceUrl: sfCoreCache.instanceUrl.replace(/\/$/, '')
      };
    }

    const body = new URLSearchParams({
      grant_type: 'password',
      username: process.env.SALESFORCE_USERNAME.trim(),
      password: process.env.SALESFORCE_PASSWORD.trim(),
      client_id: process.env.SALESFORCE_CLIENT_ID.trim(),
      client_secret: process.env.SALESFORCE_CLIENT_SECRET.trim()
    });
    // Salesforce password grant does NOT accept a "scope" parameter (returns scope parameter not supported).

    const res = await fetch(`${login}/services/oauth2/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString()
    });
    const text = await res.text();
    let json;
    try {
      json = JSON.parse(text);
    } catch {
      throw new Error(`Password grant response not JSON: ${text.slice(0, 400)}`);
    }
    if (!res.ok) {
      throw new Error(JSON.stringify(json));
    }

    const accessToken = json.access_token;
    const instanceUrl = (
      json.instance_url ||
      process.env.SALESFORCE_INSTANCE_URL ||
      ''
    ).replace(/\/$/, '');
    const expMs = jwtExpiryMs(accessToken) || now + 90 * 60 * 1000;

    sfCoreCache = { accessToken, instanceUrl, expiresAtMs: expMs };
    console.log('[Salesforce] access token obtained via OAuth password grant');
    return { accessToken, instanceUrl };
  }

  const t = getSubjectAccessTokenStatic();
  const inst = process.env.SALESFORCE_INSTANCE_URL?.replace(/\/$/, '');
  if (!t || !inst) {
    throw new Error(
      'Configure auth: (1) JWT: SALESFORCE_JWT_KEY_PATH or SALESFORCE_JWT_PRIVATE_KEY + SALESFORCE_CLIENT_ID + SALESFORCE_USERNAME (Connected App certificate), or (2) SALESFORCE_REFRESH_TOKEN + client id/secret [npm run oauth-once], or (3) SALESFORCE_USE_PASSWORD_GRANT=true + username/password + client id/secret, or (4) SALESFORCE_ACCESS_TOKEN + SALESFORCE_INSTANCE_URL'
    );
  }
  return { accessToken: t, instanceUrl: inst };
}

async function getDataCloudIngestBearer() {
  const pre = (process.env.DATA_CLOUD_CDP_ACCESS_TOKEN || '').trim();
  const tenantFallback = (process.env.DATA_CLOUD_TENANT_HOSTNAME || '').trim();

  if (pre) {
    if (!tenantFallback) {
      throw new Error(
        'DATA_CLOUD_TENANT_HOSTNAME required when using DATA_CLOUD_CDP_ACCESS_TOKEN'
      );
    }
    console.log('[Data Cloud] using DATA_CLOUD_CDP_ACCESS_TOKEN');
    return { bearer: pre, ingestBaseUrl: ingestApiBase(tenantFallback) };
  }

  const now = Date.now();
  const bufferMs = 90_000;
  if (
    cdpBearerCache.token &&
    cdpBearerCache.apiBase &&
    cdpBearerCache.expiresAtMs - bufferMs > now
  ) {
    return {
      bearer: cdpBearerCache.token,
      ingestBaseUrl: cdpBearerCache.apiBase
    };
  }

  const { accessToken: subject, instanceUrl: coreRoot } =
    await resolveCoreAccessTokenAndInstance();

  if (!coreRoot) {
    throw new Error(
      'No Salesforce instance URL after auth — set SALESFORCE_INSTANCE_URL or use OAuth script once.'
    );
  }

  const body = new URLSearchParams({
    grant_type: 'urn:salesforce:grant-type:external:cdp',
    subject_token: subject,
    subject_token_type: 'urn:ietf:params:oauth:token-type:access_token'
  });

  const res = await fetch(`${coreRoot}/services/a360/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: body.toString()
  });
  const text = await res.text();
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    json = { raw: text };
  }

  if (!res.ok) {
    const base =
      typeof json === 'object' && json.error
        ? JSON.stringify(json)
        : text;
    const extra =
      json && json.error === 'invalid_scope'
        ? ' Need scope cdp_ingest_api on Connected App + in OAuth; run: npm run oauth-once and add SALESFORCE_REFRESH_TOKEN.'
        : '';
    throw new Error(base + extra);
  }

  const bearer = json.access_token;
  const hostRaw =
    typeof json.instance_url === 'string' && json.instance_url.trim()
      ? json.instance_url.trim()
      : tenantFallback;
  const apiBase = ingestApiBase(hostRaw);

  const expMs = jwtExpiryMs(bearer);
  const expiresAtMs = expMs > now ? expMs : now + 50 * 60 * 1000;

  if (!bearer || !apiBase || apiBase === 'https://') {
    throw new Error(`CDP exchange incomplete: ${text.slice(0, 500)}`);
  }

  cdpBearerCache = { token: bearer, apiBase, expiresAtMs };
  console.log('[Data Cloud] /services/a360/token OK; ingest:', apiBase);
  return { bearer, ingestBaseUrl: apiBase };
}

function resolveObjectApiName(source) {
  const ov = process.env[`DATA_CLOUD_OBJECT_${source.toUpperCase()}`];
  if (ov) return ov;
  return SOURCE_TO_OBJECT[source];
}

function sliceRecordsStreaming(records, maxChars) {
  const batches = [];
  let cur = [];
  for (const row of records) {
    const tryBatch = cur.length === 0 ? [row] : [...cur, row];
    if (JSON.stringify({ data: tryBatch }).length <= maxChars) {
      cur = tryBatch;
      continue;
    }
    if (cur.length > 0) {
      batches.push(cur);
      cur = [row];
      if (JSON.stringify({ data: cur }).length > maxChars) {
        throw new Error('Single row exceeds ~200 KB streaming limit.');
      }
    } else {
      throw new Error('Single row exceeds ~200 KB streaming limit.');
    }
  }
  if (cur.length) batches.push(cur);
  return batches;
}

async function upstreamPostJson(url, body, headers) {
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...headers
    },
    body: JSON.stringify(body)
  });
  const text = await res.text();
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    parsed = text;
  }
  if (!res.ok) {
    const err = new Error(typeof parsed === 'string' ? parsed : JSON.stringify(parsed));
    err.status = res.status;
    throw err;
  }
  return { status: res.status, body: parsed };
}

async function pushNativeStreaming(source, records) {
  const { bearer, ingestBaseUrl } = await getDataCloudIngestBearer();
  const connector = process.env.DATA_CLOUD_CONNECTOR_API_NAME || 'Data_Cloud_Connector';
  const objectName = resolveObjectApiName(source);
  const pathSeg = `/api/v1/ingest/sources/${encodeURIComponent(connector)}/${encodeURIComponent(objectName)}`;
  const tail =
    String(process.env.DATA_CLOUD_USE_VALIDATION_ENDPOINT || '').toLowerCase() === 'true'
      ? '/actions/test'
      : '/';
  const url = `${ingestBaseUrl.replace(/\/$/, '')}${pathSeg}${tail}`;

  const batches = sliceRecordsStreaming(records, STREAMING_MAX_BODY_CHARS);
  const summaries = [];

  console.log(`[Data Cloud] ${pathSeg}${tail} — ${records.length} rows → ${batches.length} batch(es)`);

  for (let b = 0; b < batches.length; b++) {
    try {
      const out = await upstreamPostJson(
        url,
        { data: batches[b] },
        { Authorization: `Bearer ${bearer}` }
      );
      summaries.push({
        batch: b + 1,
        batches: batches.length,
        status: out.status,
        body: out.body
      });
    } catch (e) {
      e.message = `[batch ${b + 1}/${batches.length}] ${e.message}`;
      throw e;
    }
  }

  return { urlUsed: url, batches: summaries };
}

app.post('/api/push-to-salesforce', async (req, res) => {
  const { source, records } = req.body || {};
  if (!source || !SOURCE_KEYS.includes(source)) {
    return res.status(400).json({
      ok: false,
      error: `Invalid source. Expected one of: ${SOURCE_KEYS.join(', ')}`
    });
  }
  if (!Array.isArray(records) || records.length === 0) {
    return res.status(400).json({ ok: false, error: 'records must be a non-empty array' });
  }

  const dryRun = String(process.env.DRY_RUN_SYNC || '').toLowerCase() === 'true';

  if (dryRun) {
    return res.json({
      ok: true,
      dryRun: true,
      message: 'DRY_RUN_SYNC=true — no outbound HTTP.',
      sample: { source, recordCount: records.length }
    });
  }

  try {
    if (useNativeDataCloudStreaming()) {
      const upstream = await pushNativeStreaming(source, records);
      return res.json({ ok: true, mode: 'data_cloud_streaming', upstream });
    }

    const url = getLegacyIngestUrl(source);
    if (!url) {
      return res.status(501).json({
        ok: false,
        error:
          'Auth not configured. Set JWT key + CLIENT_ID + USERNAME, or SALESFORCE_USE_PASSWORD_GRANT + credentials, or SALESFORCE_REFRESH_TOKEN, or SALESFORCE_ACCESS_TOKEN. See /api/sync-help'
      });
    }

    const payload = { source, recordCount: records.length, records };
    const auth =
      process.env.DATA_CLOUD_AUTH_HEADER ||
      (process.env.SALESFORCE_ACCESS_TOKEN
        ? `Bearer ${process.env.SALESFORCE_ACCESS_TOKEN}`
        : null);
    const result = await upstreamPostJson(url, payload, auth ? { Authorization: auth } : {});
    return res.json({ ok: true, mode: 'legacy_url', upstream: result.body });
  } catch (e) {
    console.error('[push-to-salesforce]', e);
    return res.status(e.status || 502).json({
      ok: false,
      error: e.message || 'Upstream request failed'
    });
  }
});

app.get('/api/health', (_req, res) => {
  const native = useNativeDataCloudStreaming();
  res.json({
    ok: true,
    ingestConfigured: Boolean(
      process.env.DATA_CLOUD_INGEST_URL ||
        native ||
        (process.env.SALESFORCE_INSTANCE_URL && getSubjectAccessTokenStatic()) ||
        useJwtBearer() ||
        hasRefreshCredentials() ||
        usePasswordGrant()
    ),
    dataCloudStreaming: native,
    authMode: useJwtBearer()
      ? 'jwt_bearer'
      : hasRefreshCredentials()
        ? 'connected_app_refresh'
        : usePasswordGrant()
          ? 'password_grant'
          : hasPreexchangedCdpToken()
            ? 'cdp_jwt_env'
            : getSubjectAccessTokenStatic()
              ? 'static_token'
              : 'none',
    dryRunSync: String(process.env.DRY_RUN_SYNC || '').toLowerCase() === 'true'
  });
});

app.get('/api/sync-help', (_req, res) => {
  res.type('text/plain').send(
    [
      'Data Cloud Sync — click Sync; server uses .env (no iframe OAuth at click time).',
      '',
      'A) JWT BEARER (server-to-server, no password in .env)',
      '   Connected App: enable "Use digital signatures", upload your certificate, note Consumer Key.',
      '   Create an X.509 cert + private key (openssl), register the cert on the app; pre-authorize the integration user for the app.',
      '   Scopes: api, cdp_ingest_api (and any others your org requires).',
      '   .env: SALESFORCE_JWT_KEY_PATH=./keys/server.key (or SALESFORCE_JWT_PRIVATE_KEY with literal PEM)',
      '   SALESFORCE_CLIENT_ID=<Consumer Key> SALESFORCE_USERNAME=<integration user>',
      '   SALESFORCE_LOGIN_URL=https://login.salesforce.com (sandbox: https://test.salesforce.com)',
      '   Optional: SALESFORCE_JWT_AUDIENCE=https://login.salesforce.com — must match org login host / My Domain if used.',
      '   Unset SALESFORCE_REFRESH_TOKEN / SALESFORCE_PASSWORD if switching to JWT (JWT takes precedence when key + client id + username set).',
      '',
      'B) PASSWORD GRANT (no browser OAuth)',
      '   External Client / Connected App: enable "Allow OAuth Username-Password Flows", relax IP for testing.',
      '   Scopes include api + cdp_ingest_api.',
      '   .env: SALESFORCE_USE_PASSWORD_GRANT=true + CLIENT_ID + CLIENT_SECRET + USERNAME + PASSWORD',
      '   Password often = SalesforcePassword concatenated with Security Token (Personal Settings → Reset Token).',
      '   Leave DATA_CLOUD_INGEST_URL blank. Restart npm start → Import workbook → Sync.',
      '',
      'C) REFRESH TOKEN (browser OAuth)',
      '   npm run oauth-once (needs policies fixed if you saw OAUTH_APPROVAL_ERROR_*). Paste SALESFORCE_REFRESH_TOKEN.',
      '   CALLBACK must match SALESFORCE_REDIRECT_URI; npm start must be running for localhost redirect.',
      '',
      'D) Static session token: SALESFORCE_ACCESS_TOKEN + SALESFORCE_INSTANCE_URL (often lacks cdp_ingest_api).',
      ''
    ].join('\n')
  );
});

app.get('/api/data-files', (_req, res) => {
  const dir = path.join(__dirname, 'data');
  if (!fs.existsSync(dir)) {
    return res.json({ ok: true, folder: dir, exists: false, files: [] });
  }
  const names = fs.readdirSync(dir).filter((n) => !n.startsWith('.')).sort();
  return res.json({
    ok: true,
    folder: dir,
    exists: true,
    files: names.map((name) => ({ name, url: `/data/${encodeURIComponent(name)}` }))
  });
});

app.listen(PORT, () => {
  console.log(`FSC Portal Demo: http://localhost:${PORT}`);
  console.log(`  Banking:      http://localhost:${PORT}/banking/`);
  console.log(`  Insurance:    http://localhost:${PORT}/insurance/`);
  console.log(`  Employment:   http://localhost:${PORT}/employment/`);
  console.log(`  Trading:      http://localhost:${PORT}/trading/`);
  console.log(`  Health:       http://localhost:${PORT}/api/health`);
  if (hasJwtKeyConfigured() && !(process.env.SALESFORCE_CLIENT_ID || '').trim()) {
    console.warn(
      '  WARN: SALESFORCE_JWT_KEY_PATH set but SALESFORCE_CLIENT_ID is empty. Paste Consumer Key from DataCloudIngest → View Consumer Details.'
    );
  }
  if (useNativeDataCloudStreaming()) {
    console.log(`  Data Cloud ingest: READY — connector ${process.env.DATA_CLOUD_CONNECTOR_API_NAME || 'Data_Cloud_Connector'}`);
    if (useJwtBearer()) {
      console.log(`  Auth: OAuth JWT bearer (Consumer Key → iss — no Consumer Secret used on JWT token POST)`);
      const cid = (process.env.SALESFORCE_CLIENT_ID || '').trim();
      if (
        cid.length > 12 &&
        (process.env.SALESFORCE_CLIENT_SECRET || '').trim().length > 0
      ) {
        console.log(`  JWT note: SALESFORCE_CLIENT_SECRET is set but not used by JWT; you can leave it blank for JWT-only.`);                                                                     
      }
    } else if (hasRefreshCredentials()) console.log(`  Auth: Connected App refresh_token (auto)`);
    else if (usePasswordGrant()) console.log(`  Auth: OAuth password grant (auto)`);
  } else {
    console.log(`  Data Cloud: run "npm run oauth-once" once, then restart`);
  }
});
