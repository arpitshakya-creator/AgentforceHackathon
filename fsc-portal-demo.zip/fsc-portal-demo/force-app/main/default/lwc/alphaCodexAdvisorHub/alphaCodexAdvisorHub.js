import { LightningElement, api } from "lwc";
import { NavigationMixin } from "lightning/navigation";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import { getAllUtilityInfo, open as openUtility } from "lightning/platformUtilityBarApi";

export default class AlphaCodexAdvisorHub extends NavigationMixin(LightningElement) {
  @api agentApiName = "Wealth_Advisory_Agent";
  @api utilityLabelContains = "Wealth";
  @api agentRelativeUrl = "";
  @api launchUtterance = "";

  panelOpen = false;
  draftPrompt = "";
  _launching = false;

  get isLaunching() {
    return this._launching;
  }

  get launchLabel() {
    return this._launching ? "Opening…" : "Ask your advisor";
  }

  get agentDisplayName() {
    const raw = (this.agentApiName || "Wealth_Advisory_Agent").trim();
    return raw.replace(/_/g, " ");
  }

  handleClosePanel() {
    this.panelOpen = false;
  }

  handleBackdropClick() {
    this.panelOpen = false;
  }

  handleDraftInput(event) {
    this.draftPrompt = event.target.value;
  }

  async handleCopyDraft() {
    const text = (this.draftPrompt || "").trim();
    if (!text) {
      this.dispatchEvent(
        new ShowToastEvent({
          title: "AlphaCodex",
          message: "Write something first, then copy it if you’d like to paste into chat.",
          variant: "info"
        })
      );
      return;
    }
    await this.copyText(text);
  }

  async handleRelaunchUtility() {
    const fromDraft = this.draftPrompt && this.draftPrompt.trim();
    const fromDesign = this.launchUtterance && this.launchUtterance.trim();
    const starter = fromDraft || fromDesign || "";
    await this.runAgentFlow(starter, false);
  }

  async handleOpenAgent() {
    const starter = this.launchUtterance ? this.launchUtterance.trim() : "";
    await this.runAgentFlow(starter, true);
  }

  async runAgentFlow(utterance, showPanelOnStart) {
    if (this._launching) {
      return;
    }
    this._launching = true;

    if (showPanelOnStart) {
      this.panelOpen = true;
    }

    try {
      const opened = await this.tryOpenUtilityBar(utterance);

      if (!opened && this.agentRelativeUrl && this.agentRelativeUrl.trim()) {
        this[NavigationMixin.Navigate]({
          type: "standard__webPage",
          attributes: {
            url: this.agentRelativeUrl.trim()
          }
        });
        if (utterance) {
          await this.copyText(utterance);
        }
      } else if (!opened) {
        this.dispatchEvent(
          new ShowToastEvent({
            title: "AlphaCodex",
            message:
              "Add your advisor to this app’s utility bar in App Manager, or set a fallback page URL on this component.",
            variant: "warning",
            mode: "dismissable"
          })
        );
        if (utterance) {
          await this.copyText(utterance);
        }
      }
    } catch (e) {
      this.dispatchEvent(
        new ShowToastEvent({
          title: "Could not open advisor",
          message:
            (e && e.body && e.body.message) ||
            e.message ||
            "This app needs a utility bar with your advisor available.",
          variant: "error",
          mode: "sticky"
        })
      );
    } finally {
      this._launching = false;
    }
  }

  utilityIdMatch(entry) {
    if (!entry) {
      return false;
    }
    const label = `${entry.label || entry.tooltipLabel || entry.utilityLabel || ""}`.toLowerCase();
    const componentName = `${entry.componentName || entry.componentDef || ""}`.toLowerCase();
    const rawApi = (this.agentApiName || "").trim().toLowerCase();
    let matchApi = false;
    if (rawApi) {
      const spaced = rawApi.replace(/_/g, " ");
      const compact = rawApi.replace(/_/g, "");
      matchApi =
        label.includes(rawApi) ||
        label.includes(spaced) ||
        label.includes(compact) ||
        componentName.includes(rawApi) ||
        componentName.includes(compact);
    }
    const hint = (this.utilityLabelContains || "").trim().toLowerCase();
    const matchHint = hint && (label.includes(hint) || componentName.includes(hint));
    return Boolean(matchApi || matchHint);
  }

  async tryOpenUtilityBar(utterance) {
    let infos;
    try {
      infos = await getAllUtilityInfo();
    } catch (e) {
      return false;
    }

    if (!infos || !infos.length) {
      return false;
    }

    const match = infos.find((u) => this.utilityIdMatch(u));

    if (!match) {
      return false;
    }

    const utilityId = match.utilityId || match.id;
    if (!utilityId) {
      return false;
    }

    try {
      await openUtility(utilityId);
    } catch (e) {
      throw e;
    }

    if (utterance) {
      await this.copyText(utterance);
    }

    return true;
  }

  async copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      this.dispatchEvent(
        new ShowToastEvent({
          title: "AlphaCodex",
          message: "Copied — you can paste it into your advisor chat.",
          variant: "success",
          mode: "dismissable"
        })
      );
    } catch (e) {
      this.dispatchEvent(
        new ShowToastEvent({
          title: "Copy text",
          message: text.length > 220 ? `${text.substring(0, 220)}…` : text,
          variant: "info",
          mode: "sticky"
        })
      );
    }
  }
}
