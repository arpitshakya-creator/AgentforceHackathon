/**
 * Generates 450 matched client rows per workbook (four workbooks).
 * Client_IDs: CUST-1001 … CUST-1450 — same IDs in all files (unified profile demo).
 */
const fs = require('fs');
const path = require('path');

function escapeCsv(cell) {
  if (cell === null || cell === undefined) return '';
  const s = String(cell);
  if (/[",\r\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

function writeCsv(filename, rows) {
  if (!rows.length) throw new Error('No rows');
  const keys = Object.keys(rows[0]);
  const lines = [keys.map(escapeCsv).join(',')];
  for (const row of rows) {
    lines.push(keys.map((k) => escapeCsv(row[k])).join(','));
  }
  const fp = path.join(OUT_DIR, filename);
  fs.writeFileSync(fp, lines.join('\r\n'), 'utf8');
  console.log('Wrote', fp, '(' + rows.length + ' rows)');
}

const OUT_DIR = path.join(__dirname, '..', 'data');
const N = 450;
const START_ID = 1001;

const firstNames = [
  'Sneha',
  'Ravi',
  'Aryan',
  'Priya',
  'Amit',
  'Kavitha',
  'Rohit',
  'Ananya',
  'Vikram',
  'Divya',
  'Arjun',
  'Neha',
  'Karan',
  'Pooja',
  'Rajesh',
  'Meera',
  'Suresh',
  'Lakshmi',
  'Nikhil',
  'Shruti'
];
const lastNames = ['Sharma', 'Patel', 'Iyer', 'Nair', 'Kapoor', 'Reddy', 'Mehta', 'Desai', 'Kulkarni', 'Joshi'];
const employers = [
  'ABC Technologies Pvt Ltd',
  'FinServe Global',
  'Horizon Analytics',
  'WestCoast Systems',
  'Urban Retail Corp',
  'BluePeak Consulting'
];
const mumbaiAreas = ['Bandra West', 'Andheri East', 'Powai', 'Worli', 'BKC', 'Malad'];
  'Senior Software Engineer',
  'Product Manager',
  'Finance Analyst',
  'Operations Lead',
  'HR Business Partner',
  'Sales Manager',
  'Data Scientist'
];
function padId(n) {
  return `CUST-${n}`;
}

function jsonStr(obj) {
  return JSON.stringify(obj);
}

function randomItem(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function buildName(seed, forceFirst, forceLast) {
  if (forceFirst && forceLast) return `${forceFirst} ${forceLast}`;
  const fi = firstNames[seed % firstNames.length];
  const la = lastNames[Math.floor(seed / 7) % lastNames.length];
  return `${fi} ${la}`;
}

function buildBankingRow(i) {
  const idNum = START_ID + i;
  const clientId = padId(idNum);
  const name = i === 0 ? 'Sneha Sharma' : buildName(i);
  const email =
    i === 0 ? 'sneha.sharma@example.com' : name.toLowerCase().replace(/\s+/g, '.') + '@example.com';
  const balance = i === 0 ? 1200000 : randomInt(200000, 5000000);
  const recent =
    i === 0
      ? [
          { date: '2024-06-14', amount: -5000, desc: 'Utility Bill' },
          { date: '2024-06-12', amount: 100000, desc: 'Salary Credit' }
        ]
      : [
          { date: '2024-06-14', amount: -5000, desc: 'Utility Bill' },
          { date: '2024-06-12', amount: 100000, desc: 'Salary Credit' }
        ];
  if (i % 3 === 0 && i !== 0) recent.push({ date: '2024-06-10', amount: -15000, desc: 'Card Payment' });
  const channels = ['WhatsApp', 'SMS', 'Email'];
  const hh =
    i === 0
      ? ['Ravi Sharma (spouse)', 'Aryan Sharma (child)']
      : [`${randomItem(firstNames)} ${randomItem(lastNames)} (spouse)`];

  return {
    Client_ID: clientId,
    Full_Name: name,
    DOB: i === 0 ? '1985-06-15' : `${1975 + (i % 30)}-${String((i % 12) + 1).padStart(2, '0')}-${String((i % 27) + 1).padStart(2, '0')}`,
    Contact_Number: i === 0 ? '+91 9876543210' : `+91 98${String(70000000 + idNum).slice(0, 8)}`,
    Email: email,
    Address:
      i === 0
        ? 'Flat 12, Sunrise Apartments, Mumbai'
        : `Flat ${(i % 40) + 1}, ${randomItem(['Sunrise', 'Greenwood', 'Ocean'])} Apartments, ${randomItem(mumbaiAreas)}, Mumbai`,
    Household_Members: jsonStr(hh),
    Account_Number: i === 0 ? 'SB123456789' : `SB${String(123450000 + idNum)}`,
    Account_Type: i === 0 ? 'Savings' : randomItem(['Savings', 'Current', 'Fixed Deposit']),
    Account_Balance: balance,
    Last_Transaction_Date: '2024-06-15',
    Recent_Transactions: jsonStr(recent),
    KYC_Status: 'Verified',
    Preferred_Contact_Channel: i === 0 ? 'WhatsApp' : randomItem(channels)
  };
}

function buildInsuranceRow(i) {
  const idNum = START_ID + i;
  const clientId = padId(idNum);
  const ben =
    i === 0
      ? ['Ravi Sharma (spouse)', 'Aryan Sharma (child)']
      : [`${randomItem(firstNames)} ${randomItem(lastNames)} (spouse)`];
  const claims =
    i % 5 === 0
      ? [{ date: '2023-04-10', amount: 100000, status: 'Settled' }]
      : [{ date: '', amount: 0, status: 'None' }];

  return {
    Client_ID: clientId,
    Policy_Number: i === 0 ? 'INS-789456' : `INS-${789000 + idNum}`,
    Policy_Type: i === 0 ? 'Term Life' : randomItem(['Term Life', 'Health', 'Motor', 'ULIP']),
    Coverage_Amount: i === 0 ? 5000000 : randomInt(500000, 20000000),
    Premium_Amount: i === 0 ? 12000 : randomInt(6000, 48000),
    Premium_Payment_Frequency: randomItem(['Annual', 'Quarterly', 'Monthly']),
    Policy_Start_Date: '2022-01-01',
    Policy_End_Date: '2032-01-01',
    Beneficiaries: jsonStr(ben),
    Last_Claim_Date: i === 0 || i % 5 === 0 ? '2023-04-10' : '',
    Claims_History: i === 0 ? jsonStr([{ date: '2023-04-10', amount: 100000, status: 'Settled' }]) : jsonStr(claims),
    Policy_Status: 'Active',
    Preferred_Contact_Channel: i === 0 ? 'Email' : randomItem(['Email', 'WhatsApp', 'SMS'])
  };
}

function buildEmploymentRow(i) {
  const idNum = START_ID + i;
  const clientId = padId(idNum);
  const namePart = i === 0 ? 'sneha.sharma' : `user${idNum}`;
  const milestones = [
    { date: '2020-08-01', milestone: 'Completed MBA' },
    { date: '2023-01-15', milestone: 'Promoted to Senior Engineer' }
  ];
  if (i % 2 === 1) milestones.push({ date: '2021-03-10', milestone: 'Certification earned' });

  return {
    Client_ID: clientId,
    Employer_Name: i === 0 ? 'ABC Technologies Pvt Ltd' : randomItem(employers),
    Job_Title: i === 0 ? 'Senior Software Engineer' : randomItem(jobs),
    Annual_Income: i === 0 ? 1800000 : randomInt(900000, 3200000),
    Joining_Date: '2018-07-01',
    Last_Promotion_Date: '2023-01-15',
    Work_Milestones: jsonStr(milestones),
    Work_Email: i === 0 ? 'sneha.sharma@abc.com' : `${namePart}@${randomItem(['abc.com', 'finserve.in', 'horizon.io'])}`,
    Preferred_Contact_Channel: i === 0 ? 'SMS' : randomItem(['SMS', 'Email', 'WhatsApp'])
  };
}

function buildTradingRow(i) {
  const idNum = START_ID + i;
  const clientId = padId(idNum);
  const h1 = { symbol: 'TCS', quantity: i === 0 ? 100 : randomInt(10, 200), avg_price: 3200 };
  const h2 = { symbol: 'RELIANCE', quantity: i === 0 ? 50 : randomInt(5, 100), avg_price: 2300 };
  const holdings = i % 2 === 0 ? [h1, h2] : [h1];
  const trades = [
    {
      date: '2024-06-14',
      symbol: 'TCS',
      quantity: 20,
      price: 3300,
      buy_sell: 'Buy'
    }
  ];
  const alerts = [{ date: '2024-06-15', event: 'TCS stock dropped 5%' }];

  return {
    Client_ID: clientId,
    Portfolio_ID: i === 0 ? 'PORT-456123' : `PORT-${456000 + idNum}`,
    Holding_Symbols: jsonStr(holdings),
    Total_Portfolio_Value: i === 0 ? 750000 : randomInt(350000, 2200000),
    Risk_Profile: i === 0 ? 'Moderate' : randomItem(['Low', 'Moderate', 'High']),
    Last_Trade_Date: '2024-06-14',
    Recent_Trades: jsonStr(trades),
    Market_Alerts: jsonStr(alerts),
    Preferred_Contact_Channel: i === 0 ? 'WhatsApp' : randomItem(['WhatsApp', 'SMS', 'Email'])
  };
}

function writeExcel(rows, basename) {
  const XLSX = require('xlsx');
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Records');
  const fp = path.join(OUT_DIR, `${basename}.xlsx`);
  XLSX.writeFile(wb, fp);
  console.log('Wrote', fp, '(' + rows.length + ' rows)');
}

function main() {
  if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

  const banking = [];
  const insurance = [];
  const employment = [];
  const trading = [];

  for (let i = 0; i < N; i += 1) {
    banking.push(buildBankingRow(i));
    insurance.push(buildInsuranceRow(i));
    employment.push(buildEmploymentRow(i));
    trading.push(buildTradingRow(i));
  }

  writeCsv('Banking_Customers.csv', banking);
  writeCsv('Insurance_Customers.csv', insurance);
  writeCsv('Employment_Customers.csv', employment);
  writeCsv('Trading_Customers.csv', trading);

  try {
    writeExcel(banking, 'Banking_Customers');
    writeExcel(insurance, 'Insurance_Customers');
    writeExcel(employment, 'Employment_Customers');
    writeExcel(trading, 'Trading_Customers');
  } catch (e) {
    console.warn('Could not write .xlsx (install deps: npm install). CSV files are sufficient for import:', e.message);
  }

  fs.writeFileSync(
    path.join(OUT_DIR, 'README_IMPORT.txt'),
    [
      'Four datasets in CSV AND (when deps installed) Excel .xlsx format.',
      'Matching Client_ID: CUST-1001 … CUST-1450 (450 unified clients total).',
      'First customer row aligns with Sneha Sharma sample across portals.',
      '',
      'Portal: Import the matching workbook into Banking / Insurance / Employment / Trading,',
      'then Sync to Salesforce Data Cloud (configure DATA_CLOUD_INGEST_URL in server .env).'
    ].join('\r\n'),
    'utf8'
  );

  console.log('\nDone. 450 unified Client_IDs (CUST-1001..CUST-1450) across all files.');
  console.log('Spotlight row 1: Sneha Sharma (CUST-1001) aligns across Banking / Insurance / Employment / Trading.\n');
}

main();
