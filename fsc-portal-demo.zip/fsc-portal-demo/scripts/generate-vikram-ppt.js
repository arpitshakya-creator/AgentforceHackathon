/**
 * Generates Vikram use case deck (6 slides). Run: npm run ppt:vikram
 */
const path = require('path');
const pptxgen = require('pptxgenjs');

const OUT = path.join(__dirname, '..', 'Vikram-Market-Monitoring-Use-Case.pptx');

const TITLE_COLOR = '0F172A';
const ACCENT = '1E40AF';
const BODY_COLOR = '334155';

function titleSlide(pptx, title, subtitle, footer) {
  const slide = pptx.addSlide();
  slide.background = { color: 'F8FAFC' };
  slide.addText(title, {
    x: 0.6,
    y: 1.8,
    w: 8.8,
    h: 1.2,
    fontSize: 32,
    bold: true,
    color: TITLE_COLOR,
    fontFace: 'Calibri'
  });
  slide.addText(subtitle, {
    x: 0.6,
    y: 3.0,
    w: 8.8,
    h: 1.0,
    fontSize: 18,
    color: ACCENT,
    fontFace: 'Calibri'
  });
  if (footer) {
    slide.addText(footer, {
      x: 0.6,
      y: 5.0,
      w: 8.8,
      h: 0.4,
      fontSize: 11,
      color: '64748B',
      fontFace: 'Calibri'
    });
  }
}

function contentSlide(pptx, title, bullets, extraLines) {
  const slide = pptx.addSlide();
  slide.background = { color: 'FFFFFF' };
  slide.addShape(pptx.ShapeType.rect, {
    x: 0,
    y: 0,
    w: 10,
    h: 0.12,
    fill: { color: ACCENT },
    line: { color: ACCENT, width: 0 }
  });
  slide.addText(title, {
    x: 0.6,
    y: 0.45,
    w: 8.8,
    h: 0.65,
    fontSize: 22,
    bold: true,
    color: TITLE_COLOR,
    fontFace: 'Calibri'
  });
  const textBlocks = bullets.map((b) => ({
    text: b,
    options: { bullet: true, fontSize: 14, color: BODY_COLOR, fontFace: 'Calibri' }
  }));
  slide.addText(textBlocks, {
    x: 0.6,
    y: 1.25,
    w: 8.8,
    h: 3.8,
    valign: 'top',
    lineSpacingMultiple: 1.15
  });
  if (extraLines && extraLines.length) {
    slide.addText(
      extraLines.join('\n'),
      {
        x: 0.6,
        y: 4.55,
        w: 8.8,
        h: 0.9,
        fontSize: 12,
        italic: true,
        color: '64748B',
        fontFace: 'Calibri'
      }
    );
  }
}

function twoColumnSlide(pptx, title, leftTitle, leftBullets, rightTitle, rightBullets) {
  const slide = pptx.addSlide();
  slide.background = { color: 'FFFFFF' };
  slide.addShape(pptx.ShapeType.rect, {
    x: 0,
    y: 0,
    w: 10,
    h: 0.12,
    fill: { color: ACCENT },
    line: { color: ACCENT, width: 0 }
  });
  slide.addText(title, {
    x: 0.6,
    y: 0.45,
    w: 8.8,
    h: 0.65,
    fontSize: 22,
    bold: true,
    color: TITLE_COLOR,
    fontFace: 'Calibri'
  });

  slide.addText(leftTitle, {
    x: 0.6,
    y: 1.15,
    w: 4.2,
    h: 0.45,
    fontSize: 14,
    bold: true,
    color: ACCENT,
    fontFace: 'Calibri'
  });
  slide.addText(
    leftBullets.map((b) => ({
      text: b,
      options: { bullet: true, fontSize: 13, color: BODY_COLOR, fontFace: 'Calibri' }
    })),
    { x: 0.6, y: 1.55, w: 4.2, h: 3.5, valign: 'top', lineSpacingMultiple: 1.12 }
  );

  slide.addText(rightTitle, {
    x: 5.2,
    y: 1.15,
    w: 4.2,
    h: 0.45,
    fontSize: 14,
    bold: true,
    color: ACCENT,
    fontFace: 'Calibri'
  });
  slide.addText(
    rightBullets.map((b) => ({
      text: b,
      options: { bullet: true, fontSize: 13, color: BODY_COLOR, fontFace: 'Calibri' }
    })),
    { x: 5.2, y: 1.55, w: 4.2, h: 3.5, valign: 'top', lineSpacingMultiple: 1.12 }
  );
}

async function main() {
  const pptx = new pptxgen();
  pptx.layout = 'LAYOUT_16x9';
  pptx.author = 'Team';
  pptx.title = 'Market Monitoring — Vikram Use Case';
  pptx.subject = 'Financial Services Cloud, Data Cloud, Agentforce';

  titleSlide(
    pptx,
    'Market Monitoring for Relationship Managers',
    'Vikram use case — Financial Services Cloud · Data Cloud · Agentforce',
    'Team submission'
  );

  twoColumnSlide(
    pptx,
    'Challenge and vision',
    'The challenge',
    [
      'Relationship Managers manage large books with limited time',
      'Client and market context is fragmented across systems',
      'Personal outreach and call prep are slow and manual',
      'Research and operations need aligned, timely information'
    ],
    'Vision',
    [
      'One harmonized client view in Data Cloud',
      'Agent-assisted insights, briefs, and segmentation',
      'CRM and Slack stay in step with harmonized data'
    ]
  );

  contentSlide(
    pptx,
    'From demo sources to Data Cloud',
    [
      'Demo portal: banking, employment, insurance, and trading segments',
      'Excel import and sync via Data Cloud ingestion API',
      'Data lands in data lake objects; identity resolution across sources',
      'Mapped to data model objects (DMOs) for Salesforce and agents'
    ],
    ['Flow: Portal → Ingestion → Data lake objects → DMOs']
  );

  contentSlide(
    pptx,
    'Wealth Compass — agent in context',
    [
      'Custom Lightning Web Component with Nest Compass; Agentforce embedded',
      'Personalized market insight with client-specific messaging',
      'Pre-call brief: account, portfolio, employment, insurance, preferences',
      'High-risk client list for focused outreach',
      'Reload to CRM: Financial Data custom object',
      'Slack: post briefs to #wealth-advisory for research alignment'
    ]
  );

  contentSlide(
    pptx,
    'Implementation highlights',
    [
      'ClientProfileService — Data Cloud APIs for profile, insight, and brief',
      'HighRiskCustomersService — high-risk segmentation',
      'Dedicated action — upsert harmonized rows into Financial Data',
      'Agent topics, actions, and instructions for governed responses',
      'Slack integration for channel posts'
    ]
  );

  contentSlide(
    pptx,
    'Integrated operating model',
    [
      'Unified data in Data Cloud supports trusted answers',
      'Agent delivers insights and briefs with current context',
      'Financial Data maintains the operational CRM record',
      'Slack connects RM and research on one summary'
    ],
    [
      'In short: Data Cloud holds the unified picture; the agent uses it at conversation time;',
      'Financial Data carries the operational record in Salesforce;',
      'Slack supports internal coordination — a practical path for relationship teams.'
    ]
  );

  await pptx.writeFile({ fileName: OUT });
  console.log('Created:', OUT);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
