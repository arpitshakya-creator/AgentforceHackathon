/**
 * One-time: OAuth authorize (with PKCE) → paste redirect URL → prints refresh_token for .env
 * Salesforce often requires PKCE ("missing required code challenge" without these params).
 *
 * Prerequisites: Connected App callback matches SALESFORCE_REDIRECT_URI;
 * scopes: api refresh_token offline_access cdp_ingest_api
 */
require('dotenv').config();
const crypto = require('crypto');
const readline = require('readline');

const login = (process.env.SALESFORCE_LOGIN_URL || 'https://login.salesforce.com').replace(/\/$/, '');
  const redirectUri =
  process.env.SALESFORCE_REDIRECT_URI || 'http://localhost:3780/oauth/callback';

function base64UrlEncode(buf) {
  return buf
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=/g, '');
}

/** RFC 7636 PKCE verifier + S256 challenge */
function createPkcePair() {
  const verifier = base64UrlEncode(crypto.randomBytes(32));
  const challenge = base64UrlEncode(
    crypto.createHash('sha256').update(verifier, 'utf8').digest()
  );
  return { verifier, challenge };
}

async function main() {
  const clientId = process.env.SALESFORCE_CLIENT_ID?.trim();
  const clientSecret = process.env.SALESFORCE_CLIENT_SECRET?.trim();
  if (!clientId || !clientSecret) {
    console.error('Set SALESFORCE_CLIENT_ID and SALESFORCE_CLIENT_SECRET in .env first.');
    process.exit(1);
  }

  const { verifier, challenge } = createPkcePair();

  const scope = encodeURIComponent('api refresh_token offline_access openid cdp_ingest_api');

  const authUrl =
    `${login}/services/oauth2/authorize?response_type=code&client_id=${encodeURIComponent(clientId)}` +
    `&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${scope}` +
    `&code_challenge=${encodeURIComponent(challenge)}&code_challenge_method=S256`;

  console.log('\nPKCE enabled — code_verifier stays in memory for this run only.');
  if (/\/localhost:/i.test(redirectUri)) {
    console.log(
      '\n0) Start your app ON THIS PORT FIRST: npm start  (so the browser can redirect to localhost)\n'
    );
  }
  console.log('\n1) Open this URL in your browser and sign in:\n');
  console.log(authUrl);
  console.log(
    '\n2) Copy the FULL address bar URL after redirect (must contain code=…).\n'
  );

  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const line = await new Promise((resolve) => {
    rl.question('3) Paste the full redirect URL here: ', resolve);
  });
  rl.close();

  let code;
  try {
    const u = new URL(line.trim());
    code = u.searchParams.get('code');
    const errParam = u.searchParams.get('error');
    if (!code && errParam) {
      console.error('Authorize error:', u.searchParams.get('error_description') || errParam);
      process.exit(1);
    }
  } catch {
    console.error('Could not parse URL. Paste the full URL starting with https://');
    process.exit(1);
  }
  if (!code) {
    console.error('No "code" in URL — Connected App blocked or scopes missing.');
    process.exit(1);
  }

  const body = new URLSearchParams({
    grant_type: 'authorization_code',
    client_id: clientId,
    client_secret: clientSecret,
    redirect_uri: redirectUri,
    code,
    code_verifier: verifier
  });

  const res = await fetch(`${login}/services/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: body.toString()
  });
  const text = await res.text();
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    console.error('Token response:', text);
    process.exit(1);
  }
  if (!res.ok) {
    console.error('Exchange failed:', json);
    process.exit(1);
  }

  console.log('\n--- Copy into .env (never commit); then npm start ---\n');
  if (json.refresh_token) {
    console.log(`SALESFORCE_REFRESH_TOKEN=${json.refresh_token}`);
    console.log('SALESFORCE_USE_PASSWORD_GRANT=false');
  } else {
    console.error('No refresh_token. Add refresh_token/offline_access scopes on Connected App.');
  }
  if (json.instance_url) {
    console.log(`SALESFORCE_INSTANCE_URL=${json.instance_url}`);
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
