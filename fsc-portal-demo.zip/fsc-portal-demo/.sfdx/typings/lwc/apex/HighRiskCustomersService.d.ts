declare module "@salesforce/apex/HighRiskCustomersService.getCustomersByRiskProfileForUi" {
  export default function getCustomersByRiskProfileForUi(param: {riskProfile: any}): Promise<any>;
}
declare module "@salesforce/apex/HighRiskCustomersService.getCustomersByRiskProfilePageForUi" {
  export default function getCustomersByRiskProfilePageForUi(param: {riskProfile: any, pageSize: any, pageNumber: any}): Promise<any>;
}
